void inicjuj(int n, int k, int *D);

void podlej(int a, int b);

int dojrzale(int a, int b);
